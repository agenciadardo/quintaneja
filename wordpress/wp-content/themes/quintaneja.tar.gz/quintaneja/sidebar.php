        <div id="barra-lateral-direita" class="grid_4">

            <div class="videos">
                <div class="cabecalho-box">
                    <h1>Vídeos</h1>
                </div>

                <div class="video-embedded">
                    <!-- <img src="" alt="" /> -->
                </div> <!-- endOf Vídeo embedded -->
            </div> <!-- endOf Vídeos -->

            <div class="player-musica">
                <div class="cabecalho-box">
                    <h1>Música</h1>
                </div>

                <div class="player">

                </div> <!-- endOf Player -->
            </div> <!-- endOf Player de música -->

            <div class="ingressos">

                <div class="cabecalho-box">
                    <h1>Ingressos</h1>
                </div>

                <div class="ingresso-antecipado">
                    <div class="mensagem-ingresso">
                        <h2>Compre os ingressos antecipados</h2>
                    </div> <!-- endOf Mensagem sobre ingressos antecipados -->
                </div> <!-- endOf Ingresso Antecipado -->

                <div class="pontos-de-venda">
                    <div class="mensagem-pontos-de-venda">
                        <h2>Conheça os pontos de venda</h2>
                    </div> <!-- endOf Mensagem sobre pontos de venda -->
                </div> <!-- endOf Pontos de venda -->

            </div> <!-- endOf Ingressos -->

        </div> <!-- endOf Barra lateral direita -->