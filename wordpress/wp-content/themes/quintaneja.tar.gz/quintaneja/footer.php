    <!--[if lt IE 9]>
        <div id="rodape-ie">
    <![endif]-->

    <!--[if !IE]><!-->
        <div id="rodape">        
    <!--<![endif]-->
        <p>
            Todos os direitos reservados a Festa Quintaneja &#8212; <?php echo date(Y); ?>
        </p>

        <p>
            <a href="http://www.agenciadardo.com.br">
                &plus; Dardo &amp; Dagny
            </a>
        </p>
    </div> <!-- endOf Rodapé -->
    <?php wp_footer(); ?>
    </body>
</html>